#! /usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from os.path import basename
import numpy as np
from utils.progressbar import wrap_iterator


def stack_frame(input_list, input_paths, frame_num_dict, num_stack, num_skip,
                progressbar=False):
    """Stack & skip some frames. This implementation is based on
       https://arxiv.org/abs/1507.06947.
           Sak, Haşim, et al.
           "Fast and accurate recurrent neural network acoustic models for speech recognition."
           arXiv preprint arXiv:1507.06947 (2015).
    Args:
        input_list (list): list of input data
        input_paths (list): paths to input data. This is used to get the
            number of frames from frame_num_dict.
        frame_num_dict (dict):
            key (string) => utterance index
            value (int) => the number of frames
        num_stack (int): the number of frames to stack
        num_skip (int): the number of frames to skip
        progressbar (bool, optional): if True, visualize progressbar
    Returns:
        stacked_input_list (list): list of frame-stacked inputs
    """
    if num_stack == 1 and num_stack == 1:
        return input_list

    if num_stack < num_skip:
        raise ValueError('num_skip must be less than num_stack.')

    input_size = input_list[0].shape[1]
    utt_num = len(input_paths)

    stacked_input_list = []
    for i_utt in wrap_iterator(range(utt_num), progressbar):
        # Per utterance
        input_name = basename(input_paths[i_utt]).split('.')[0]
        frame_num = frame_num_dict[input_name]
        frame_num_decimated = frame_num / num_skip
        if frame_num_decimated != int(frame_num_decimated):
            frame_num_decimated += 1
        frame_num_decimated = int(frame_num_decimated)

        stacked_frames = np.zeros(
            (frame_num_decimated, input_size * num_stack))
        stack_count = 0  # counter for stacked_frames
        stack = []
        for i_frame, frame in enumerate(input_list[i_utt]):
            #####################
            # final frame
            #####################
            if i_frame == len(input_list[i_utt]) - 1:
                # Stack the final frame
                stack.append(frame)

                while stack_count != int(frame_num_decimated):
                    # Concatenate stacked frames
                    for i_stack in range(len(stack)):
                        stacked_frames[stack_count][input_size *
                                                    i_stack:input_size * (i_stack + 1)] = stack[i_stack]
                    stack_count += 1

                    # Delete some frames to skip
                    for _ in range(num_skip):
                        if len(stack) != 0:
                            stack.pop(0)

            ########################
            # first & middle frames
            ########################
            elif len(stack) < num_stack:
                # Stack some frames until stack is filled
                stack.append(frame)

                if len(stack) == num_stack:
                    # Concatenate stacked frames
                    for i_stack in range(num_stack):
                        stacked_frames[stack_count][input_size *
                                                    i_stack:input_size * (i_stack + 1)] = stack[i_stack]
                    stack_count += 1

                    # Delete some frames to skip
                    for _ in range(num_skip):
                        stack.pop(0)

        stacked_input_list.append(stacked_frames)

    return np.array(stacked_input_list)
