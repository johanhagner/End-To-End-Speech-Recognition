# TODO
- Beam serarch decoder in the Attention-based models
- LAS(Listen, Attend, and Spell) model
- Add Gausian noise to inputs and weights when training
- Warp CTC loss training
- WFST decoder
- Sequence Training such as sMBR
